let totalAmount = 0;

// Function to Add Items to Invoice
function addItem() {
    let itemName = document.getElementById("itemName").value;
    let price = parseFloat(document.getElementById("price").value);

    if (itemName === "" || isNaN(price)) {
        alert("Please enter valid item details!");
        return;
    }

    // Add item to invoice table
    let table = document.getElementById("invoiceTable").getElementsByTagName("tbody")[0];
    let row = table.insertRow();
    let cell1 = row.insertCell(0);
    let cell2 = row.insertCell(1);

    cell1.innerHTML = itemName;
    cell2.innerHTML = "₹" + price.toFixed(2);

    // Update total
    totalAmount += price;
    document.getElementById("totalAmount").innerText = totalAmount.toFixed(2);

    // Clear inputs
    document.getElementById("itemName").value = "";
    document.getElementById("price").value = "";
}

// Function to Generate Invoice as PDF
function generateInvoice() {
    let customerName = document.getElementById("customerName").value;
    if (customerName === "") {
        alert("Please enter the customer name!");
        return;
    }

    let invoiceContent = `
        <h2>Grow Invoice</h2>
        <p><strong>Customer Name:</strong> ${customerName}</p>
        <h3>Items Purchased</h3>
        <table border="1">
            <tr>
                <th>Item</th>
                <th>Price</th>
            </tr>
    `;

    let rows = document.getElementById("invoiceTable").getElementsByTagName("tbody")[0].rows;
    for (let i = 0; i < rows.length; i++) {
        invoiceContent += `
            <tr>
                <td>${rows[i].cells[0].innerText}</td>
                <td>${rows[i].cells[1].innerText}</td>
            </tr>
        `;
    }

    invoiceContent += `
        </table>
        <h3>Total Amount: ₹${totalAmount.toFixed(2)}</h3>
    `;

    // Open new tab with invoice
    let win = window.open("", "", "width=800,height=600");
    win.document.write(invoiceContent);
    win.document.close();
    win.print();
}